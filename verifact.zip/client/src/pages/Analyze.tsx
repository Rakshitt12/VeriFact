import { useMemo, useState } from "react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";
import {
  ArrowLeft,
  ArrowUpRight,
  Check,
  ChevronDown,
  ExternalLink,
  FileCheck2,
  Fingerprint,
  Globe2,
  Info,
  Link2,
  Menu,
  MoreHorizontal,
  ShieldCheck,
  Sparkles,
  X,
} from "lucide-react";

const supporting = [
  { source: "Reuters", title: "What the latest data tells us about the claim", meta: "Independent reporting · 2 days ago", tone: "blue" },
  { source: "National Research Archive", title: "Primary document: findings and methodology", meta: "Official source · 4 days ago", tone: "green" },
];
const contradicting = [{ source: "FactCheck.org", title: "The context missing from the viral version", meta: "Fact-check · 5 days ago", tone: "orange" }];

function BrandMark() {
  return <Link href="/" className="brand-mark" aria-label="VeriFact home"><span className="brand-glyph"><span /></span><span>verifact</span></Link>;
}

function ReportHeader() {
  const [, navigate] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  return <header className="site-header report-header"><div className="container nav-inner"><button className="back-button" onClick={() => navigate("/")}><ArrowLeft size={16} /> New verification</button><BrandMark /><div className="nav-actions"><span className="report-state"><span className="live-dot" /> Report ready</span><button className="icon-button mobile-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="Open menu">{menuOpen ? <X size={19} /> : <Menu size={19} />}</button><button className="icon-button hide-mobile" onClick={() => toast.info("Report actions are coming soon.")}><MoreHorizontal size={19} /></button></div></div></header>;
}

function ScoreRing({ score }: { score: number }) {
  const circumference = 2 * Math.PI * 66;
  const dash = circumference * score / 100;
  return <div className="score-ring" style={{ "--score-dash": `${dash}px`, "--score-gap": `${circumference - dash}px` } as React.CSSProperties}><svg viewBox="0 0 160 160" aria-hidden="true"><circle className="score-track" cx="80" cy="80" r="66" /><circle className="score-progress" cx="80" cy="80" r="66" /></svg><div className="score-value"><strong>{score}</strong><span>/ 100</span></div></div>;
}

function ScoreBreakdown() {
  const rows = [["Evidence agreement", 24], ["Source quality", 18], ["Independent sources", 16], ["Fact-check evidence", 12], ["Official evidence", 8], ["Transparency", 4]];
  return <div className="breakdown-card"><div className="card-heading"><div><span className="eyebrow">The signal behind the score</span><h2>Why this score?</h2></div><button className="info-button" aria-label="Score methodology"><Info size={16} /></button></div><div className="breakdown-rows">{rows.map(([label, value]) => <div className="breakdown-row" key={label as string}><span>{label}</span><strong>+{value}</strong><div className="breakdown-bar"><span style={{ width: `${Number(value) * 3.6}%` }} /></div></div>)}</div><div className="breakdown-total"><span>Credibility score</span><strong>82 / 100</strong></div><p className="method-note"><ShieldCheck size={14} /> Based on retrieved evidence and configured verification factors. This is not a probability of truth.</p></div>;
}

function EvidenceCard({ item }: { item: { source: string; title: string; meta: string; tone: string } }) {
  return <article className="evidence-card"><div className="evidence-top"><span className={`source-avatar ${item.tone}`}>{item.source.slice(0, 1)}</span><span className="source-name">{item.source}</span><button className="evidence-link" aria-label={`Open ${item.source}`} onClick={() => toast.info("Source preview will open when source links are connected.")}><ExternalLink size={14} /></button></div><h3>{item.title}</h3><p>{item.meta}</p><div className="evidence-tag"><Check size={13} /> Supports the claim</div></article>;
}

export default function Analyze() {
  const storedInput = typeof window !== "undefined" ? sessionStorage.getItem("verifact-input") : null;
  const claim = useMemo(() => storedInput || "A new study shows that urban green spaces improve mental health within weeks.", [storedInput]);
  const [activeTab, setActiveTab] = useState<"supporting" | "contradicting">("supporting");
  return <div className="app-shell report-shell"><ReportHeader /><main className="report-main"><div className="container report-container"><div className="report-breadcrumb"><span>Verification report</span><span>/</span><span>VF-0248</span><span className="report-date">Updated just now</span></div><section className="report-intro"><div><span className="eyebrow">Claim under investigation</span><h1>“{claim}”</h1><div className="claim-meta"><span><Link2 size={14} /> Direct claim</span><span><Globe2 size={14} /> Evidence window: 30 days</span></div></div><button className="button button-outline hide-mobile" onClick={() => toast.success("Report link copied to clipboard.")}><ArrowUpRight size={15} /> Share report</button></section><section className="verdict-grid"><div className="score-panel"><div className="panel-label"><span className="eyebrow">Credibility score</span><span className="verified-chip"><FileCheck2 size={13} /> Verified</span></div><div className="score-layout"><ScoreRing score={82} /><div className="score-copy"><span className="verdict-label">Mostly supported</span><h2>Evidence leans<br />in one direction.</h2><p>Most retrieved sources agree with the claim, with one important context gap to keep in view.</p></div></div></div><div className="verdict-panel"><span className="eyebrow">Verdict</span><div className="verdict-big"><span className="verdict-dot" />Mostly supported</div><p>The available evidence supports the core claim, but the exact timeframe is not consistently established across sources.</p><div className="verdict-bottom"><span><Fingerprint size={14} /> 4 independent sources</span><span><Sparkles size={14} /> 1 context gap</span></div></div></section><ScoreBreakdown /><section className="report-section"><div className="section-title-row"><div><span className="eyebrow">Deconstructed</span><h2>Claims analyzed <span>01</span></h2></div><button className="collapse-button">Collapse <ChevronDown size={15} /></button></div><div className="claim-row"><div className="claim-index">01</div><div className="claim-content"><div className="claim-row-top"><h3>Urban green spaces improve mental health</h3><span className="status-badge supported"><Check size={13} /> Supported</span></div><p>The core relationship is supported by multiple studies and independent reporting. The “within weeks” timeframe is less certain.</p><div className="claim-tags"><span>Core claim</span><span>Evidence confidence: high</span></div></div></div></section><section className="report-section evidence-section"><div className="section-title-row"><div><span className="eyebrow">Source trail</span><h2>Evidence <span>03</span></h2></div><div className="evidence-tabs"><button className={activeTab === "supporting" ? "active" : ""} onClick={() => setActiveTab("supporting")}>Supporting <b>02</b></button><button className={activeTab === "contradicting" ? "active orange" : ""} onClick={() => setActiveTab("contradicting")}>Contradicting <b>01</b></button></div></div><div className="evidence-grid">{(activeTab === "supporting" ? supporting : contradicting).map((item) => <EvidenceCard key={item.source} item={item} />)}</div></section><section className="gap-callout"><div className="gap-icon"><Info size={21} /></div><div><span className="eyebrow">Verification gap</span><h2>The timeframe needs more evidence.</h2><p>Sources support the general benefit, but none of the primary material confirms that the effect appears within weeks. Treat that detail as unverified rather than false.</p></div><button className="icon-button" onClick={() => toast.info("More gap details are coming soon.")}><ArrowUpRight size={18} /></button></section><section className="sources-footer"><div><span className="eyebrow">Audit trail</span><h2>Everything in one place.</h2></div><div className="source-count"><strong>03</strong><span>sources reviewed<br />across 2 source types</span></div><button className="button button-dark" onClick={() => toast.info("Export is coming soon.")}>Export report <ArrowUpRight size={15} /></button></section></div></main><footer className="site-footer"><div className="container footer-inner"><BrandMark /><span>Evidence before certainty.</span><span>Report VF-0248</span></div></footer></div>;
}

